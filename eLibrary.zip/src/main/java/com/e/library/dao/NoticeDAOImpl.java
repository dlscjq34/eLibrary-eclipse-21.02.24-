package com.e.library.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.e.library.mapper.NoticeMapper;
import com.e.library.model.NoticeVO;

@Repository
public class NoticeDAOImpl implements NoticeDAO {

	@Autowired
	NoticeMapper mapper;
	
	@Override
	public void insert(NoticeVO noticeVO) {
		mapper.insert(noticeVO);
	}

	@Override
	public NoticeVO getNotice(int noticeId) {
		return mapper.getNotice(noticeId);
	}

	@Override
	public List<NoticeVO> getNotices(Map<String, String> map) {
		return mapper.getNotices(map);
	}

	@Override
	public List<NoticeVO> getAllNotices() {
		return mapper.getAllNotices();
	}

	@Override
	public List<NoticeVO> getNewNotices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getNoticeCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
