package com.e.library.dao;

import java.util.List;
import java.util.Map;

import com.e.library.model.BookVO;
import com.e.library.model.NoticeVO;

public interface NoticeDAO {
	
	public void insert(NoticeVO noticeVO);//공지 등록
	
	public NoticeVO getNotice(int noticeId);//공지 찾기
	
	public List<NoticeVO> getNotices(Map<String, String> map);//공지들 찾기
	
	public List<NoticeVO> getAllNotices();//모든 공지
	
	public List<NoticeVO> getNewNotices();//신규 공지 TOP 5
	
	public int getNoticeCount();//모든 공지 수

}
