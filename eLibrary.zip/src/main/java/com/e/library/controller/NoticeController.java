package com.e.library.controller;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.e.library.model.BookVO;
import com.e.library.model.NoticeVO;
import com.e.library.service.NoticeServiceImpl;

@Controller
public class NoticeController {
	
	@Autowired
	private NoticeServiceImpl service;
	
	
	//공지등록 폼
	@GetMapping("/regNoticeForm")
	public String regNoticeForm() {

		return "admin/regNotice";
	}
	
	
	
	//공지등록 처리
	@ResponseBody
	@PostMapping("/regNotice")
	public void regNotice(@RequestBody NoticeVO noticeVO) {
		
		service.insert(noticeVO);
	}
	
	
	
	//공지목록
	@GetMapping("/noticeList")
	public String noticeList(Model model) {
		
		List<NoticeVO> list = service.getAllNotices();
		model.addAttribute("list", list);
		
		return "notice/noticeList";
	}
	
	
	
	//안드로이드 공지목록
	@PostMapping("/androidNoticeList")
	public void androidNoticeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		List<NoticeVO> noticeList = service.getAllNotices();
		
		JSONArray jArray = new JSONArray();
		for (int i = 0; i < noticeList.size(); i++) {
			JSONObject jsonRow = new JSONObject();
			jsonRow.put("noticeId", noticeList.get(i).getNoticeId());
			jsonRow.put("regDate", new SimpleDateFormat("yyyy-MM-dd").format(noticeList.get(i).getRegDate()));//시분초에서 : 와 .이 json 유효성 검사에 위반됨. 그래서 시분초 뺐다. 
			jsonRow.put("title", noticeList.get(i).getTitle());
			jsonRow.put("content", noticeList.get(i).getContent());
			jArray.add(jsonRow);
		}
		

		JSONObject jsonObj = new JSONObject();
		jsonObj.put("result", jArray);
		PrintWriter out = response.getWriter();
		out.print(jsonObj);
	}
	
	
	
	
	//공지보기
	@GetMapping("/notice")
	public String notice(int noticeId, Model model) {

		model.addAttribute("notice", service.getNotice(noticeId));
		
		return "notice/notice";
	}
	
	
	
	//공지 검색
	@ResponseBody
	@PostMapping("/searchNotice")
	public List<NoticeVO> searchNotice(@RequestBody Map<String, String> map) {

		return service.getNotices(map);
	}
//	
//	
//	
//	
//	
//	
//	//신간도서
//	@GetMapping("newBookList")
//	public String newBookList(Model model) {
//		
//		List<BookVO> list = service.getNewBooks();
//		model.addAttribute("list", list);
//		
//		
//		return "book/newBookList";
//	}
//	
//	
//	
//	

//	
//	
//			
//	
//	

//	
//	
//	
//	//관심 도서 등록
//	@GetMapping("/favorBook")
//	public String favorBook(DTO dto, Model model) {
//
//		System.out.println(dto);
//		
//		
//		return "/book/book";
//		
//	}
//	
//	
//	
//	
//	
//	

//	
//	
//	
//	//안드로이드 도서검색
//	@PostMapping("/androidSearchBook")
//	public void androidSearchBook(HttpServletRequest request, HttpServletResponse response) throws Exception {
//		
//		Map<String, String> map = new HashMap<String, String>();
//		map.put("column", request.getParameter("column"));
//		map.put("searchBook", request.getParameter("searchBook"));
//		
//		List<BookVO> bookList = service.getBooks(map);
//		
//		JSONArray jArray = new JSONArray();
//		for (int i = 0; i < bookList.size(); i++) {
//			JSONObject jsonRow = new JSONObject();
//			jsonRow.put("bookId", bookList.get(i).getBookId());
//			jsonRow.put("bookName", bookList.get(i).getBookName());
//			jsonRow.put("writer", bookList.get(i).getWriter());
//			jsonRow.put("publisher", bookList.get(i).getPublisher());
//			jsonRow.put("publiDate", new SimpleDateFormat("yyyy-MM-dd").format(bookList.get(i).getPubliDate()));//시분초에서 : 와 .이 json 유효성 검사에 위반됨. 그래서 시분초 뺐다. 
//			jsonRow.put("status", bookList.get(i).getStatus());
//			jArray.add(jsonRow);
//		}
//		
//		
//		JSONObject jsonObj = new JSONObject();
//		jsonObj.put("result", jArray);
//		PrintWriter out = response.getWriter();
//		out.print(jsonObj);
//	}
	
	
}
