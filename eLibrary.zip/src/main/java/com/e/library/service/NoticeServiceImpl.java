package com.e.library.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.e.library.dao.NoticeDAOImpl;
import com.e.library.model.NoticeVO;

@Service
public class NoticeServiceImpl implements NoticeService {
	
	@Autowired
	NoticeDAOImpl dao;

	@Override
	public void insert(NoticeVO noticeVO) {
		dao.insert(noticeVO);
	}

	@Override
	public NoticeVO getNotice(int noticeId) {
		return dao.getNotice(noticeId);
	}

	@Override
	public List<NoticeVO> getNotices(Map<String, String> map) {
		return dao.getNotices(map);
	}

	@Override
	public List<NoticeVO> getAllNotices() {
		return dao.getAllNotices();
	}

	@Override
	public List<NoticeVO> getNewNotices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getNoticeCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
