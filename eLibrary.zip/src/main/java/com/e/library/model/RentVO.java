package com.e.library.model;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class RentVO {
	private String rentId;	
	private String bookId;	
	private String memberId;	
	private Timestamp rentDate;	
	private Timestamp dueDate;	
	private Timestamp returnDate;	
}
