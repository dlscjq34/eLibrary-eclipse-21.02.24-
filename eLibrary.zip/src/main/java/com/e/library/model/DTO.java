package com.e.library.model;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class DTO {
	private String memberId;
	private String rentId;
	private String bookId;
	private String bookName;
	private Timestamp rentDate;	
	private Timestamp dueDate;	
	private Timestamp returnDate;	
	private String bookStatus;
	private int lateDate;	
}
