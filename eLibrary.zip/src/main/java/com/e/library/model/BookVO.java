package com.e.library.model;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class BookVO {
	private String bookId;	
	private String bookName;	
	private String writer;	
	private String publisher;	
	private Timestamp publiDate;	
	private String status;
}
