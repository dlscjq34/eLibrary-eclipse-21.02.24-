package com.e.library.model;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class MemberVO {
	private String memberId;	
	private String memberName;	
	private String memberRole;	
	private String pswd;	
	private String addr;	
	private String tel;
	private Timestamp regDate;	
	private int favorBook;
	private int howManyLate;	
}
