
$(function() {
	 
	
	$("#btnRegNotice").click(function() { regNotice() });//공지 등록
	$("#btnSearchNotice").click(function() { searchNotice() });//공지 검색
	

});//ready






function regNotice() {
	
	let data= {
			title: $("#noticeTitle").val(),
			content: $("#noticeContent").val(),
		}
		
	// 빈칸체크
	if(data.title == "" || data.content == "") {
		alert("빈칸을 입력하세요");
      	return false;
	}
	
	//도서등록 처리
	$.ajax({
		type: "post",
		url: "/regNotice",
		data: JSON.stringify(data),//js를 json 문자열로
		contentType:"application/json; charset=utf-8",//서버에 데이터를 보낼 때 
		//dataType: "json"// 서버에서 응답 줄때 json을 javascript로 변경	
	})
	.done(function() {
		alert("공지가 등록되었습니다.");
		location.replace("/regNoticeForm");
	}) 
	.fail(function(request, error) {
		alert("code : "+request.status+"\n"+"message : "+request.responseText+"\n"+"error : "+error);
	});//ajax
}






function searchNotice() {	
	
	let data= {
		noticeField: $("#noticeField").val(),
		noticeWord: $("#noticeWord").val()
	}
	
	
	//공지들 검색 작업
	$.ajax({
		type: "post",
		url: "/searchNotice",
		data: JSON.stringify(data),//js를 json 문자열로
		contentType:"application/json; charset=utf-8",//서버에 데이터를 보낼 때 
		dataType: "json"// 서버에서 응답 줄때 json을 javascript로 변경	
	})
	.done(function(result) {//검색 결과
		htmlStr = "";//비동기 문자열
		
		//검색 결과가 없으면
		if(result == "") {
			alert("찾으시는 공지가 없습니다.");
		}
		//검색 결과가 있으면
		else {
			htmlStr = "<table border='1'>"+
					"<tr>"+
						"<td> 공지번호 </td>"+
						"<td> 공지명 </td>"+
						"<td> 공지일 </td>"+
					"</tr>";
			$.each(result, function(idx, list) {
				htmlStr += "<tr>"+ 
								"<td>"+ list.noticeId +"</td>"+
								"<td><a href=/notice?noticeId="+list.noticeId+">"+ list.title +"</td>"+
								"<td>"+ getFormatDate(list.regDate) +"</td>"+
							"</tr>";
			});
			htmlStr += "</table>"; 
		}
		$("#noticeTable").html(htmlStr);
	}) 
	.fail(function(request, error) {
		alert("code : "+request.status+"\n"+"message : "+request.responseText+"\n"+"error : "+error);
	});//ajax
}







//달력포맷
function getFormatDate(date){
	fmt = new Date(date);
    var year = fmt.getFullYear();              //yyyy
    var month = (1 + fmt.getMonth());          //M
    month = month >= 10 ? month : '0' + month;  //month 두자리로 저장
    var day = fmt.getDate();                   //d
    day = day >= 10 ? day : '0' + day;          //day 두자리로 저장
    return  year + '-' + month + '-' + day;     
}